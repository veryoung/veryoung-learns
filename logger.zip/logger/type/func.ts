/** 替换的原函数 */
export type OriginFunc = (...args: unknown[]) => unknown;

/** 原函数的上下文 */
export type OriginFuncContext = any;
