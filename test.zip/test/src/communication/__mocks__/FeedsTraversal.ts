export default class FeedsTraversal {
  public static async traversal() {
    return {
      success: true,
      content: {},
    };
  }
}
