export { shouldComponentUpdate, countReRender } from '@tencent/luckbox-react-optimize';
