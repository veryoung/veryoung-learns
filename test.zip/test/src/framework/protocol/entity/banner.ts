/** banner实体 */
export class Banner {
  /** banner对应跳转地址 */
  public jumpUrl = '';
  /** banner图 */
  public bannerUrl = '';
}
