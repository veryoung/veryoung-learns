/** author实体 */
export class Author {
  /** 作者名 */
  public authorName = '';
  /** 作者标识 */
  public authorId = '';
  /** 作者相关图片 */
  public picUrl = '';
}
