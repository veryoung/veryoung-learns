/** 追更书籍 */
export class CatchUpBooks {
  /** 追更内容 */
  public pushTips = '';
  /** 资源id */
  public resourceId = '';
  /** 资源名称 */
  public resourceName='';
  /** 图片地址 */
  public picUrl?: string;
  /** 跳转地址 */
  public jumpUrl?: string;
}
