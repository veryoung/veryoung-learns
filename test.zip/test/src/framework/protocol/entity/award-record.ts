/** 福利卡片中奖信息 */
export class AwardRecord {
  /** 头像 */
  public avatar = '';
  /** 中奖信息 */
  public awardDesc = '';
}
