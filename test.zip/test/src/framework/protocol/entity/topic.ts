/** 话题 */
export class Topic {
  /** 话题ID */
  public topicId = '';
  /** 话题名 */
  public topicName = '';
  /** 话题地址 */
  public topicUrl = '';
}
