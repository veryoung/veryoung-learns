export const TAB_LIST = [
  {
    sGroupId: '25001',
    sGroupName: '推荐榜',
  },
  {
    sGroupId: '986',
    sGroupName: '热度榜',
  },
  {
    sGroupId: '987',
    sGroupName: '飙升榜',
  },
  { sGroupId: '993',
    sGroupName: '完本榜',
  },
];
