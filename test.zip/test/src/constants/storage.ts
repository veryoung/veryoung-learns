/** 首屏数据缓存key */
export const FIRST_SCREEN_DATA_LOCAL_KEY = 'NovelFeedsLocalFirstScreenData';
/** 动态tab数据缓存key */
export const DYNAMIC_TABS = 'DynamicTabs';

/** 存储key */
export enum STORAGE {
  /** 实验配置 */
  EXPERTSDATA = 'ExpertsData'
}
